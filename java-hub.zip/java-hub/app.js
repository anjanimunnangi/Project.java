(function () {
  "use strict";

  /* ================= DATA ================= */
  var CATS = [
    { id: "start", name: "Getting started" },
    { id: "oop", name: "Classes & OOP" },
    { id: "strings", name: "Strings" },
    { id: "exc", name: "Exceptions & byte streams" },
    { id: "io", name: "Char streams & threads" }
  ];
  var CAT = {};
  CATS.forEach(function (c) { CAT[c.id] = c; });

  var PDFS = [
    { id: "install", file: "pdfs/java-installation-lab.pdf", title: "Installing Java and running Hello World", cat: "start", type: "Lab guide", pages: 3,
      desc: "Install Oracle JDK on Windows, check it with the command line, set JAVA_HOME and PATH, then compile and run your first program.",
      tags: ["JDK", "JAVA_HOME", "PATH", "javac", "Hello World"] },
    { id: "compare", file: "pdfs/language-comparison-lab.pdf", title: "Comparing Java with C, C++, Python and JavaScript", cat: "start", type: "Lab", pages: 1,
      desc: "Build a comparison table across 19 parameters, from compiler or interpreter to memory management, security and popular IDEs.",
      tags: ["comparison", "compiler", "memory", "languages"] },
    { id: "unit2", file: "pdfs/unit2-java-programs.pdf", title: "Unit 2 Java programs", cat: "oop", type: "Programs", pages: 5,
      desc: "Fourteen experiments with two programs each: classes, objects, constructors, this, garbage collection, overloading, static, final and inner classes.",
      tags: ["class", "object", "constructor", "this", "static", "final", "inner class", "overloading"] },
    { id: "inherit", file: "pdfs/inheritance-programs.pdf", title: "Inheritance programs", cat: "oop", type: "Programs", pages: 2,
      desc: "Ten problems on single and multilevel inheritance, super, method overriding, dynamic method dispatch and a banking application.",
      tags: ["inheritance", "super", "overriding", "polymorphism", "dispatch"] },
    { id: "packages", file: "pdfs/packages-interfaces.pdf", title: "Packages and access control", cat: "oop", type: "Experiments", pages: 5,
      desc: "Create and import packages, compare public, private, protected and default access, and use CLASSPATH to find your classes.",
      tags: ["package", "import", "access modifiers", "CLASSPATH", "interface"] },
    { id: "strings", file: "pdfs/string-handling.pdf", title: "String handling and basic inheritance", cat: "strings", type: "Experiments", pages: 2,
      desc: "String constructors, the StringBuffer class and StringTokenizer, plus two short experiments on inheritance and super.",
      tags: ["String", "StringBuffer", "StringTokenizer", "constructors"] },
    { id: "exceptions", file: "pdfs/exception-handling-byte-streams.pdf", title: "Exception handling and byte streams", cat: "exc", type: "Lab", pages: 1,
      desc: "Ten exception experiments (try, catch, throw, throws, finally, custom exceptions) and five byte stream experiments with file copy.",
      tags: ["try", "catch", "finally", "throw", "throws", "custom exception", "FileInputStream", "FileOutputStream"] },
    { id: "threads", file: "pdfs/character-streams-multithreading.pdf", title: "Character streams and multithreading", cat: "io", type: "Lab", pages: 1,
      desc: "Read and write text with Reader, Writer, FileReader and FileWriter, then create threads with Thread and Runnable, and control them with isAlive and join.",
      tags: ["Reader", "Writer", "FileReader", "FileWriter", "thread", "Runnable", "join", "isAlive"] }
  ];
  var PDF = {};
  PDFS.forEach(function (p) { PDF[p.id] = p; });

  var PATH = [
    { pdf: "install", cat: "start", title: "Install the JDK", text: "Download, install and verify Java. Set JAVA_HOME and PATH." },
    { pdf: "unit2", cat: "oop", title: "Classes and objects", text: "Constructors, this, static, final, overloading and inner classes." },
    { pdf: "inherit", cat: "oop", title: "Inheritance", text: "Reuse code with extends, super, overriding and dynamic dispatch." },
    { pdf: "packages", cat: "oop", title: "Packages", text: "Organise classes, import them and control access." },
    { pdf: "strings", cat: "strings", title: "Strings", text: "String, StringBuffer and StringTokenizer." },
    { pdf: "exceptions", cat: "exc", title: "Exceptions and byte streams", text: "Handle errors and copy files byte by byte." },
    { pdf: "threads", cat: "io", title: "Character streams and threads", text: "Read text files and run code concurrently." }
  ];

  var HELLO = 'public class HelloWorld {\n    public static void main(String[] args) {\n        System.out.println("Hello, Java!");\n    }\n}';
  var CMD = 'javac HelloWorld.java\njava HelloWorld';

  var SNIPPETS = [
    { name: "HelloWorld.java", cls: "HelloWorld", code: HELLO, out: "Hello, Java!" },
    { name: "Car.java", cls: "Car", out: "Vehicle speed: 80\nCar model: Swift",
      code: 'class Vehicle {\n    int speed = 80;\n    void display() { System.out.println("Vehicle speed: " + speed); }\n}\nclass Car extends Vehicle {\n    String model = "Swift";\n    void display() {\n        super.display();\n        System.out.println("Car model: " + model);\n    }\n    public static void main(String[] a) { new Car().display(); }\n}' },
    { name: "Finally.java", cls: "Finally", out: "Cannot divide by zero\nfinally always runs",
      code: 'public class Finally {\n    public static void main(String[] args) {\n        try {\n            int r = 10 / 0;\n        } catch (ArithmeticException e) {\n            System.out.println("Cannot divide by zero");\n        } finally {\n            System.out.println("finally always runs");\n        }\n    }\n}' },
    { name: "JoinDemo.java", cls: "JoinDemo", out: "worker: counting\nmain: worker finished",
      code: 'public class JoinDemo {\n    public static void main(String[] args) throws Exception {\n        Thread t = new Thread(() ->\n            System.out.println("worker: counting"));\n        t.start();\n        t.join();   // wait for the worker\n        System.out.println("main: worker finished");\n    }\n}' }
  ];

  var PROBLEMS = [
    { id: "p1", cat: "start", src: "install", level: "easy", title: "Compile and run Hello World",
      text: "Write HelloWorld.java, compile it with javac, run it with java, and confirm that the output appears in the terminal.",
      hint: "The file name must match the public class name, including capital letters.",
      code: HELLO },
    { id: "p2", cat: "oop", src: "unit2", level: "easy", title: "Student information system",
      text: "Create a Student class with roll number, name, branch and CGPA. Make an object, set its data and print it with a method.",
      hint: "Put the fields in the class, write a display() method, and call it on your object from main.",
      code: 'class Student {\n    int roll; String name, branch; double cgpa;\n    void display() {\n        System.out.println(roll + " " + name + " " + branch + " " + cgpa);\n    }\n}\npublic class Main {\n    public static void main(String[] args) {\n        Student s = new Student();\n        s.roll = 101; s.name = "Asha"; s.branch = "CSE"; s.cgpa = 8.7;\n        s.display();\n    }\n}' },
    { id: "p3", cat: "oop", src: "unit2", level: "medium", title: "Constructor overloading",
      text: "Give a class two constructors, one with no arguments and one that takes values. Create one object with each and print both.",
      hint: "Java picks the constructor by the number and types of arguments you pass to new.",
      code: 'class Box {\n    int w, h;\n    Box() { w = 1; h = 1; }\n    Box(int w, int h) { this.w = w; this.h = h; }\n    int area() { return w * h; }\n}\npublic class Main {\n    public static void main(String[] a) {\n        System.out.println(new Box().area());      // 1\n        System.out.println(new Box(4, 5).area());  // 20\n    }\n}' },
    { id: "p4", cat: "oop", src: "inherit", level: "easy", title: "Single inheritance",
      text: "Make a Person class with name and age. Extend it with a Student class that adds roll number and branch, then print all four details.",
      hint: "Student extends Person, so a Student object already has name and age.",
      code: 'class Person { String name; int age; }\nclass Student extends Person {\n    int roll; String branch;\n    void show() {\n        System.out.println(name + ", " + age + ", " + roll + ", " + branch);\n    }\n}\npublic class Main {\n    public static void main(String[] a) {\n        Student s = new Student();\n        s.name = "Ravi"; s.age = 19; s.roll = 7; s.branch = "ECE";\n        s.show();\n    }\n}' },
    { id: "p5", cat: "oop", src: "inherit", level: "medium", title: "Override a method and call super",
      text: "Create Vehicle with a speed variable and display(). Create Car with a model variable that overrides display() and uses super to reach the Vehicle version.",
      hint: "Inside the overriding method, super.display() runs the parent's code first.",
      code: SNIPPETS[1].code },
    { id: "p6", cat: "oop", src: "inherit", level: "hard", title: "Dynamic method dispatch with bank accounts",
      text: "Make an Account base class with an interest() method and two subclasses that override it. Store both in an Account array and print each interest.",
      hint: "A parent reference can hold a child object. Java chooses the method at run time from the object's real class.",
      code: 'class Account { double rate() { return 0; } }\nclass Savings extends Account { double rate() { return 4.0; } }\nclass Current extends Account { double rate() { return 0.5; } }\npublic class Main {\n    public static void main(String[] a) {\n        Account[] list = { new Savings(), new Current() };\n        for (Account acc : list)\n            System.out.println(acc.getClass().getSimpleName() + ": " + acc.rate() + "%");\n    }\n}' },
    { id: "p7", cat: "oop", src: "packages", level: "medium", title: "Create and import a package",
      text: "Create a package named mypackage with a Student class, then import and use it from a class outside the package.",
      hint: "Declare the package on the first line, make the class and method public, and compile with javac -d .",
      code: '// mypackage/Student.java\npackage mypackage;\npublic class Student {\n    public void show() { System.out.println("Student in mypackage"); }\n}\n\n// Main.java\nimport mypackage.Student;\npublic class Main {\n    public static void main(String[] a) { new Student().show(); }\n}' },
    { id: "p8", cat: "strings", src: "strings", level: "easy", title: "Edit text with StringBuffer",
      text: "Use StringBuffer to append, insert, reverse and delete characters in a word, printing the result after each step.",
      hint: "StringBuffer changes the same object. String creates a new one every time.",
      code: 'public class Main {\n    public static void main(String[] a) {\n        StringBuffer sb = new StringBuffer("Java");\n        sb.append(" Lab");      System.out.println(sb); // Java Lab\n        sb.insert(0, "Learn ");   System.out.println(sb); // Learn Java Lab\n        sb.reverse();             System.out.println(sb);\n        sb.reverse().delete(0, 6); System.out.println(sb); // Java Lab\n    }\n}' },
    { id: "p9", cat: "strings", src: "strings", level: "easy", title: "Split a sentence with StringTokenizer",
      text: "Break a sentence into words with StringTokenizer, print each word and report how many tokens there were.",
      hint: "Loop while hasMoreTokens() is true and call nextToken() inside the loop.",
      code: 'import java.util.StringTokenizer;\npublic class Main {\n    public static void main(String[] a) {\n        StringTokenizer st = new StringTokenizer("learn java by doing");\n        System.out.println("Tokens: " + st.countTokens());\n        while (st.hasMoreTokens()) System.out.println(st.nextToken());\n    }\n}' },
    { id: "p10", cat: "exc", src: "exceptions", level: "easy", title: "Catch a division by zero",
      text: "Divide two integers inside try. Catch ArithmeticException and add a finally block that always prints a message.",
      hint: "Integer division by zero throws ArithmeticException. Floating point division does not.",
      code: SNIPPETS[2].code },
    { id: "p11", cat: "exc", src: "exceptions", level: "medium", title: "Custom exception for invalid marks",
      text: "Define InvalidMarksException by extending Exception. Throw it when marks are below 0 or above 100, and catch it in main.",
      hint: "Use throw new ... to raise it, and add throws to the method signature if you do not catch it there.",
      code: 'class InvalidMarksException extends Exception {\n    InvalidMarksException(String m) { super(m); }\n}\npublic class Main {\n    static void check(int marks) throws InvalidMarksException {\n        if (marks < 0 || marks > 100)\n            throw new InvalidMarksException("Marks out of range: " + marks);\n        System.out.println("Valid: " + marks);\n    }\n    public static void main(String[] a) {\n        try { check(85); check(120); }\n        catch (InvalidMarksException e) { System.out.println(e.getMessage()); }\n    }\n}' },
    { id: "p12", cat: "exc", src: "exceptions", level: "medium", title: "Copy a file with byte streams",
      text: "Copy one file to another using FileInputStream and FileOutputStream. Handle FileNotFoundException and IOException, and close both streams.",
      hint: "try-with-resources closes the streams for you, even when an exception is thrown.",
      code: 'import java.io.*;\npublic class Copy {\n    public static void main(String[] a) {\n        try (FileInputStream in = new FileInputStream("a.txt");\n             FileOutputStream out = new FileOutputStream("b.txt")) {\n            int b;\n            while ((b = in.read()) != -1) out.write(b);\n            System.out.println("Copied");\n        } catch (FileNotFoundException e) {\n            System.out.println("Input file not found");\n        } catch (IOException e) {\n            System.out.println("I/O error: " + e.getMessage());\n        }\n    }\n}' },
    { id: "p13", cat: "io", src: "threads", level: "medium", title: "Run a thread and wait for it",
      text: "Create a thread by implementing Runnable, start it, check isAlive(), and use join() so main waits for it to finish.",
      hint: "start() begins the new thread. join() makes the calling thread wait until it ends.",
      code: 'public class Main implements Runnable {\n    public void run() { System.out.println("running in " + Thread.currentThread().getName()); }\n    public static void main(String[] a) throws Exception {\n        Thread t = new Thread(new Main(), "worker");\n        t.start();\n        System.out.println("alive? " + t.isAlive());\n        t.join();\n        System.out.println("done, alive? " + t.isAlive()); // false\n    }\n}' }
  ];

  var QUIZ = [
    { q: "Which command compiles <code>HelloWorld.java</code>?", o: ["java HelloWorld.java", "javac HelloWorld.java", "compile HelloWorld", "jvm HelloWorld.class"], a: 1, why: "javac is the compiler. It turns source into bytecode, and java then runs that bytecode on the JVM." },
    { q: "What does <code>super.display()</code> do inside a subclass method?", o: ["Calls the parent class version of display()", "Creates a new parent object", "Deletes the overriding method", "Calls display() on the main class"], a: 0, why: "super refers to the parent part of the current object, so the overridden parent method still runs." },
    { q: "Which member can a class in a different package access when it does not extend the class?", o: ["private", "default (no modifier)", "protected", "public"], a: 3, why: "Only public members are visible everywhere. Protected also needs a subclass, and default needs the same package." },
    { q: "Which block runs whether or not an exception is thrown?", o: ["catch", "finally", "throws", "else"], a: 1, why: "finally runs after try and catch in both cases, which makes it the place to release resources." },
    { q: "What is the difference between <code>String</code> and <code>StringBuffer</code>?", o: ["String can be changed in place, StringBuffer cannot", "StringBuffer can be changed in place, String cannot", "They are the same class", "StringBuffer only stores numbers"], a: 1, why: "String objects are immutable. StringBuffer edits one object, which is cheaper for repeated changes." },
    { q: "What does <code>t.join()</code> do?", o: ["Starts thread t", "Stops thread t at once", "Makes the calling thread wait until t ends", "Gives thread t a higher priority"], a: 2, why: "join() blocks the caller until the target thread finishes, which lets you control execution order." }
  ];

  /* ================= HELPERS ================= */
  function $(s, r) { return (r || document).querySelector(s); }
  function $$(s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); }
  function esc(s) { return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;"); }
  function store(k, v) {
    try { if (v === undefined) return localStorage.getItem(k); localStorage.setItem(k, v); } catch (e) { return null; }
    return null;
  }
  var toastTimer;
  function toast(msg) {
    var t = $("#toast"); t.textContent = msg; t.classList.add("show");
    clearTimeout(toastTimer); toastTimer = setTimeout(function () { t.classList.remove("show"); }, 2600);
  }

  var KEYWORDS = "abstract|boolean|break|byte|case|catch|char|class|continue|double|else|extends|final|finally|float|for|if|implements|import|instanceof|int|interface|long|new|package|private|protected|public|return|static|super|this|throw|throws|try|void|while";
  var TOKEN = new RegExp("(//[^\\n]*)|(\"(?:[^\"\\\\]|\\\\.)*\")|\\b(" + KEYWORDS + ")\\b|\\b(\\d+(?:\\.\\d+)?)\\b|\\b([A-Z][A-Za-z0-9_]*)\\b", "g");
  function highlight(code) {
    var out = "", last = 0, m;
    TOKEN.lastIndex = 0;
    while ((m = TOKEN.exec(code))) {
      out += esc(code.slice(last, m.index));
      var cls = m[1] ? "cmt" : m[2] ? "str" : m[3] ? "key" : m[4] ? "num" : "type";
      out += '<span class="tk-' + cls + '">' + esc(m[0]) + "</span>";
      last = m.index + m[0].length;
    }
    return out + esc(code.slice(last));
  }

  /* ================= THEME & NAV ================= */
  var root = document.documentElement;
  var savedTheme = store("jb-theme");
  if (savedTheme === "dark" || savedTheme === "light") root.setAttribute("data-theme", savedTheme);
  $("#themeBtn").addEventListener("click", function () {
    var cur = root.getAttribute("data-theme") ||
      (window.matchMedia && matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light");
    var next = cur === "dark" ? "light" : "dark";
    root.setAttribute("data-theme", next); store("jb-theme", next);
  });
  var nav = $("#nav"), menuBtn = $("#menuBtn");
  menuBtn.addEventListener("click", function () {
    var open = nav.classList.toggle("open");
    menuBtn.setAttribute("aria-expanded", String(open));
  });

  /* ================= HERO ================= */
  var totalPages = PDFS.reduce(function (n, p) { return n + p.pages; }, 0);
  $("#heroFacts").innerHTML = "<span><b>" + PDFS.length + "</b> PDFs</span><span><b>" + totalPages + "</b> pages</span><span><b>" + PROBLEMS.length + "</b> practice problems</span>";

  var termTabs = $("#termTabs"), termCode = $("#termCode"), termCmd = $("#termCmd"), termOut = $("#termOut");
  var current = 0, typing = null;
  var reduce = window.matchMedia && matchMedia("(prefers-reduced-motion: reduce)").matches;

  SNIPPETS.forEach(function (s, i) {
    var b = document.createElement("button");
    b.type = "button"; b.className = "term-tab"; b.setAttribute("role", "tab"); b.textContent = s.name;
    b.addEventListener("click", function () { show(i, true); });
    termTabs.appendChild(b);
  });
  var runBtn = document.createElement("button");
  runBtn.type = "button"; runBtn.className = "term-run";
  runBtn.innerHTML = '<svg viewBox="0 0 12 12" aria-hidden="true"><path d="M2 1l9 5-9 5z"/></svg>Run';
  runBtn.addEventListener("click", function () { show(current, true); });
  termTabs.appendChild(runBtn);

  function show(i, animate) {
    current = i; clearInterval(typing);
    $$(".term-tab", termTabs).forEach(function (b, n) { b.setAttribute("aria-selected", String(n === i)); });
    var s = SNIPPETS[i];
    var cmd = "javac " + s.name + " && java " + s.cls;
    if (!animate || reduce) {
      termCode.innerHTML = highlight(s.code); termCmd.textContent = cmd; termOut.textContent = s.out; return;
    }
    var n = 0, step = Math.max(2, Math.round(s.code.length / 90));
    termCmd.textContent = ""; termOut.textContent = "";
    termCode.classList.add("caret");
    typing = setInterval(function () {
      n += step;
      if (n >= s.code.length) {
        clearInterval(typing); termCode.classList.remove("caret");
        termCode.innerHTML = highlight(s.code); termCmd.textContent = cmd;
        setTimeout(function () { if (current === i) termOut.textContent = s.out; }, 350);
        return;
      }
      termCode.innerHTML = highlight(s.code.slice(0, n));
    }, 16);
  }
  show(0, false);

  /* ================= JAVA SECTION ================= */
  $("#helloCode").innerHTML = highlight(HELLO);
  $("#cmdCode").innerHTML = '<span class="tk-cmt">// compile, then run</span>\n' + esc(CMD);
  $$("[data-copy]").forEach(function (b) {
    b.addEventListener("click", function () {
      var text = b.getAttribute("data-copy") === "hello" ? HELLO : CMD;
      copyText(text, b);
    });
  });
  function copyText(text, btn) {
    function done() { var old = btn.textContent; btn.textContent = "Copied"; setTimeout(function () { btn.textContent = old; }, 1400); }
    function fallback() {
      var ta = document.createElement("textarea"); ta.value = text; ta.setAttribute("readonly", "");
      ta.style.position = "fixed"; ta.style.opacity = "0"; document.body.appendChild(ta); ta.select();
      try { document.execCommand("copy"); done(); } catch (e) { toast("Select the code and copy it manually"); }
      document.body.removeChild(ta);
    }
    if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(text).then(done, fallback);
    else fallback();
  }

  var pathEl = $("#path");
  PATH.forEach(function (st, i) {
    var li = document.createElement("li");
    li.setAttribute("data-cat", st.cat);
    li.innerHTML = '<span class="path-dot">' + (i + 1) + '</span><div><h3>' + esc(st.title) + '</h3><p>' + esc(st.text) + '</p></div>' +
      '<button class="path-link" type="button" data-view="' + st.pdf + '">View PDF</button>';
    pathEl.appendChild(li);
  });

  /* ================= LIBRARY ================= */
  var state = { q: "", cat: "all" };
  var cardsEl = $("#cards"), chipsEl = $("#chips"), qEl = $("#q"), qClear = $("#qClear");

  function chipHTML(id, label, count, dotCat, pressed) {
    return '<button type="button" class="chip" data-cat-filter="' + id + '" aria-pressed="' + pressed + '"' +
      (dotCat ? ' data-cat="' + dotCat + '"' : "") + '>' + (dotCat ? '<i style="--dot:var(--cat)"></i>' : "") + esc(label) + " <em>" + count + "</em></button>";
  }
  function buildChips(el, items, active, countFn) {
    el.innerHTML = chipHTML("all", "All", countFn("all"), "", active === "all") +
      CATS.map(function (c) { return chipHTML(c.id, c.name, countFn(c.id), c.id, active === c.id); }).join("");
  }
  buildChips(chipsEl, CATS, "all", function (id) { return id === "all" ? PDFS.length : PDFS.filter(function (p) { return p.cat === id; }).length; });

  function matches(p) {
    if (state.cat !== "all" && p.cat !== state.cat) return false;
    if (!state.q) return true;
    var hay = (p.title + " " + p.desc + " " + p.tags.join(" ") + " " + CAT[p.cat].name + " " + p.type).toLowerCase();
    return state.q.toLowerCase().split(/\s+/).filter(Boolean).every(function (w) { return hay.indexOf(w) !== -1; });
  }

  function cardHTML(p) {
    var lines = "";
    var widths = [92, 70, 84, 56, 76];
    for (var i = 0; i < 5; i++) lines += '<div class="sheet-line' + (i === 0 ? " k" : "") + '" style="width:' + (i === 0 ? 38 : widths[i]) + '%"></div>';
    return '<article class="pdf-card" data-cat="' + p.cat + '">' +
      '<div class="sheet"><div class="sheet-paper">' + lines + '</div><span class="sheet-badge">PDF</span></div>' +
      '<div class="pdf-body"><div class="pdf-meta"><span class="cat-name">' + esc(CAT[p.cat].name) + '</span><span>' + esc(p.type) + '</span><span>' + p.pages + (p.pages === 1 ? " page" : " pages") + '</span></div>' +
      '<h3>' + esc(p.title) + '</h3><p>' + esc(p.desc) + '</p>' +
      '<div class="tags">' + p.tags.slice(0, 4).map(function (t) { return '<span class="tag">' + esc(t) + '</span>'; }).join("") + '</div></div>' +
      '<div class="pdf-actions">' +
      '<button class="btn btn-sm btn-primary" type="button" data-view="' + p.id + '"><svg viewBox="0 0 24 24"><path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/></svg>View PDF</button>' +
      '<button class="btn btn-sm" type="button" data-download="' + p.id + '"><svg viewBox="0 0 24 24"><path d="M12 4v11m0 0-4-4m4 4 4-4M5 20h14"/></svg>Download</button>' +
      '</div></article>';
  }

  function renderLibrary() {
    var list = PDFS.filter(matches);
    cardsEl.innerHTML = list.map(cardHTML).join("");
    $("#empty").hidden = list.length > 0;
    var filtered = state.q || state.cat !== "all";
    $("#resultLine").textContent = list.length === PDFS.length && !filtered ? "Showing all " + PDFS.length + " PDFs" :
      "Showing " + list.length + " of " + PDFS.length + " PDFs";
    $$("[data-cat-filter]", chipsEl).forEach(function (b) { b.setAttribute("aria-pressed", String(b.getAttribute("data-cat-filter") === state.cat)); });
    qClear.hidden = !state.q;
  }
  chipsEl.addEventListener("click", function (e) {
    var b = e.target.closest("[data-cat-filter]"); if (!b) return;
    state.cat = b.getAttribute("data-cat-filter"); renderLibrary();
  });
  qEl.addEventListener("input", function () { state.q = qEl.value.trim(); renderLibrary(); });
  qClear.addEventListener("click", function () { qEl.value = ""; state.q = ""; renderLibrary(); qEl.focus(); });
  $("#resetBtn").addEventListener("click", function () { qEl.value = ""; state.q = ""; state.cat = "all"; renderLibrary(); });
  renderLibrary();

  /* ================= VIEW / DOWNLOAD ================= */
  var viewer = $("#viewer"), frame = $("#viewerFrame"), viewerId = null, lastFocus = null;
  function openViewer(id) {
    var p = PDF[id]; if (!p) return;
    viewerId = id; lastFocus = document.activeElement;
    $("#viewerTitle").textContent = p.title;
    $("#viewerTab").setAttribute("href", p.file);
    frame.src = p.file;
    viewer.hidden = false; document.body.style.overflow = "hidden";
    $("#viewerClose").focus();
  }
  function closeViewer() {
    viewer.hidden = true; frame.removeAttribute("src"); document.body.style.overflow = "";
    if (lastFocus && lastFocus.focus) lastFocus.focus();
  }
  $("#viewerClose").addEventListener("click", closeViewer);
  viewer.addEventListener("click", function (e) { if (e.target === viewer) closeViewer(); });
  document.addEventListener("keydown", function (e) { if (e.key === "Escape" && !viewer.hidden) closeViewer(); });
  $("#viewerDl").addEventListener("click", function () { if (viewerId) download(viewerId); });

  function plainDownload(p) {
    var a = document.createElement("a");
    a.href = p.file; a.download = p.file.split("/").pop();
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    toast("Downloading " + a.download);
  }
  function download(id) {
    var p = PDF[id]; if (!p) return;
    var name = p.file.split("/").pop();
    var cap = window.claude && window.claude.use ? window.claude.use("downloads") : Promise.resolve(null);
    Promise.resolve(cap).catch(function () { return null; }).then(function (dl) {
      if (!dl) { plainDownload(p); return; }
      return fetch(p.file).then(function (r) {
        if (!r.ok) throw new Error("fetch");
        return r.arrayBuffer();
      }).then(function (buf) {
        return dl.save({ filename: name, data: buf });
      }).then(function () { toast("Saved " + name); }, function (err) {
        if (err && err.code === "declined") return;
        toast("Download did not start. Use Open in new tab and save from there.");
      });
    });
  }

  document.addEventListener("click", function (e) {
    var v = e.target.closest("[data-view]");
    if (v) { openViewer(v.getAttribute("data-view")); return; }
    var d = e.target.closest("[data-download]");
    if (d) { download(d.getAttribute("data-download")); }
  });

  /* ================= TABS ================= */
  function setTab(name, scroll) {
    ["library", "practice"].forEach(function (n) {
      var on = n === name;
      $("#tab-" + n).setAttribute("aria-selected", String(on));
      $("#panel-" + n).hidden = !on;
    });
    store("jb-tab", name);
    if (scroll) $("#content").scrollIntoView({ behavior: reduce ? "auto" : "smooth" });
  }
  $$(".tab").forEach(function (t) { t.addEventListener("click", function () { setTab(t.getAttribute("data-tab"), false); }); });
  $$("a[data-tab]").forEach(function (a) {
    a.addEventListener("click", function (e) {
      e.preventDefault(); setTab(a.getAttribute("data-tab"), true);
      nav.classList.remove("open"); menuBtn.setAttribute("aria-expanded", "false");
    });
  });
  var savedTab = store("jb-tab");
  if (location.hash === "#practice" || savedTab === "practice") setTab("practice", false);

  /* ================= PRACTICE ================= */
  var done = {};
  try { done = JSON.parse(store("jb-done") || "{}") || {}; } catch (e) { done = {}; }
  var pCat = "all";
  var pChips = $("#pChips");
  buildChips(pChips, CATS, "all", function (id) { return id === "all" ? PROBLEMS.length : PROBLEMS.filter(function (p) { return p.cat === id; }).length; });

  function problemHTML(p) {
    var src = PDF[p.src];
    return '<article class="problem' + (done[p.id] ? " done" : "") + '" data-cat="' + p.cat + '" id="' + p.id + '">' +
      '<div class="problem-head"><div><h3>' + esc(p.title) + '</h3>' +
      '<div class="problem-meta"><span class="level ' + p.level + '">' + p.level + '</span><span class="cat-name">' + esc(CAT[p.cat].name) + '</span><span>From ' + esc(src.title) + '</span></div></div>' +
      '<label class="check"><input type="checkbox" data-done="' + p.id + '"' + (done[p.id] ? " checked" : "") + '> Solved</label></div>' +
      '<p>' + esc(p.text) + '</p>' +
      '<details><summary>Show hint</summary><p>' + esc(p.hint) + '</p></details>' +
      '<details><summary>Show sample solution</summary><div class="code"><button class="copy" type="button" data-copy-problem="' + p.id + '">Copy</button><pre>' + highlight(p.code) + '</pre></div></details>' +
      '<div class="problem-links"><button class="btn btn-sm" type="button" data-view="' + p.src + '">Open source PDF</button></div></article>';
  }
  function renderProblems() {
    var list = PROBLEMS.filter(function (p) { return pCat === "all" || p.cat === pCat; });
    $("#problems").innerHTML = list.map(problemHTML).join("");
    $$("[data-cat-filter]", pChips).forEach(function (b) { b.setAttribute("aria-pressed", String(b.getAttribute("data-cat-filter") === pCat)); });
    updateProgress();
  }
  function updateProgress() {
    var n = PROBLEMS.filter(function (p) { return done[p.id]; }).length;
    $("#progText").textContent = n + " of " + PROBLEMS.length;
    $("#progFill").style.width = (n / PROBLEMS.length * 100) + "%";
  }
  pChips.addEventListener("click", function (e) {
    var b = e.target.closest("[data-cat-filter]"); if (!b) return;
    pCat = b.getAttribute("data-cat-filter"); renderProblems();
  });
  $("#problems").addEventListener("change", function (e) {
    var c = e.target.closest("[data-done]"); if (!c) return;
    var id = c.getAttribute("data-done");
    if (c.checked) done[id] = 1; else delete done[id];
    store("jb-done", JSON.stringify(done));
    c.closest(".problem").classList.toggle("done", c.checked);
    updateProgress();
  });
  $("#problems").addEventListener("click", function (e) {
    var b = e.target.closest("[data-copy-problem]"); if (!b) return;
    var p = PROBLEMS.filter(function (x) { return x.id === b.getAttribute("data-copy-problem"); })[0];
    if (p) copyText(p.code, b);
  });
  renderProblems();

  /* ================= QUIZ ================= */
  var qi = 0, score = 0, answered = false;
  var quizBox = $("#quizBox");
  function renderQuiz() {
    if (qi >= QUIZ.length) {
      quizBox.innerHTML = '<p class="quiz-q">You scored ' + score + ' out of ' + QUIZ.length + '.</p>' +
        '<p class="quiz-feedback">' + (score === QUIZ.length ? "Every answer correct. Try a harder practice problem next." : "Review the PDFs for the questions you missed, then try again.") + '</p>' +
        '<div class="quiz-foot"><button class="btn btn-sm btn-primary" type="button" id="quizAgain">Try again</button></div>';
      $("#quizAgain").addEventListener("click", function () { qi = 0; score = 0; renderQuiz(); });
      return;
    }
    var q = QUIZ[qi]; answered = false;
    quizBox.innerHTML = '<p class="quiz-q">' + q.q + '</p><div class="quiz-opts">' +
      q.o.map(function (o, i) { return '<button type="button" class="opt" data-i="' + i + '">' + esc(o) + '</button>'; }).join("") +
      '</div><p class="quiz-feedback" id="quizFb" aria-live="polite"></p>' +
      '<div class="quiz-foot"><span>Question ' + (qi + 1) + ' of ' + QUIZ.length + '</span><button class="btn btn-sm" type="button" id="quizNext" hidden>' + (qi === QUIZ.length - 1 ? "See score" : "Next question") + '</button></div>';
    $("#quizNext").addEventListener("click", function () { qi++; renderQuiz(); });
  }
  quizBox.addEventListener("click", function (e) {
    var b = e.target.closest(".opt"); if (!b || answered) return;
    answered = true;
    var q = QUIZ[qi], pick = +b.getAttribute("data-i");
    $$(".opt", quizBox).forEach(function (o, i) {
      o.disabled = true;
      if (i === q.a) o.classList.add("right");
      else if (i === pick) o.classList.add("wrong");
    });
    if (pick === q.a) score++;
    $("#quizFb").textContent = (pick === q.a ? "Correct. " : "Not quite. ") + q.why;
    $("#quizNext").hidden = false;
  });
  renderQuiz();

  /* ================= NAV HIGHLIGHT ================= */
  var links = $$("[data-link]");
  function markNav() {
    var y = window.scrollY + 120, id = "home";
    ["home", "java", "content"].forEach(function (s) {
      var el = document.getElementById(s); if (el && el.offsetTop <= y) id = s;
    });
    var tab = !$("#panel-practice").hidden ? "practice" : "library";
    links.forEach(function (a) {
      var key = a.getAttribute("data-link");
      var on = id === "content" ? key === (tab === "practice" ? "practice" : "content") : key === id;
      if (on) a.setAttribute("aria-current", "true"); else a.removeAttribute("aria-current");
    });
  }
  window.addEventListener("scroll", markNav, { passive: true });
  document.addEventListener("click", function () { setTimeout(markNav, 60); });
  markNav();
})();
